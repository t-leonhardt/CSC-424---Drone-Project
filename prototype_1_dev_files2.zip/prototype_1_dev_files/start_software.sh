#!/bin/bash

tmux new-session -d -s Drone_Software

tmux new-window -t Drone_Software -n "Env_Launch" bash -c "roslaunch iq_sim agriculture.launch"
sleep 2
tmux new-window -t Drone_Software -n "SITL" bash -c "./startsitl.sh; exec bash"
sleep 2
tmux new-window -t Drone_Software -n "APM" bash -c "roslaunch iq_sim apm.launch"

sleep 2
tmux new-window -t Drone_Software -n "Movement" bash -c "rosrun iq_gnc keyboardmvmnt"

sleep 2 
tmux new-window -t Drone_Software -n "Bounding_Box" bash -c "roslaunch darknet_ros darknet_ros.launch"

tmux attach -t Drone_Software
