#include <cstdio>
#include <csignal>
#include <unistd.h>
#include <termios.h>
#include <mutex>
#include <iostream>
//#include <ros/ros.h>
#include <gnc_functions.hpp>
using std::cout;

class Drone_Keyboard_Control
{
private:
  
  static const char KEYCODE_UP    = 0x41;
  static const char KEYCODE_DOWN  = 0x42;
  static const char KEYCODE_RIGHT = 0x43;
  static const char KEYCODE_LEFT  = 0x44;

  static const char KEY_A = 0x61;
  static const char KEY_D = 0x64;
  static const char KEY_J = 0x6a;
  static const char KEY_S = 0x73;
  static const char KEY_U = 0x75;
  static const char KEY_W = 0x77;
  static const char KEY_E = 0x65;
  static const char KEY_Q = 0x71;
  static const char KEY_L = 0x6C;
  static const char KEY_P = 0x70;

  static const char KEYCODE_SPACE  = 0x20;


public:

  void keyLoop(int argc, char** argv);

private:

  static void rosSigintHandler(int sig);
  static int  canReceiveKey( const int fd );

  void showHelp();
};



void Drone_Keyboard_Control::rosSigintHandler(int sig)
{
  ros::shutdown();
}


int Drone_Keyboard_Control::canReceiveKey( const int fd )
{
  fd_set fdset;
  int ret;
  struct timeval timeout;
  FD_ZERO( &fdset );
  FD_SET( fd , &fdset );

  timeout.tv_sec = 0;
  timeout.tv_usec = 0;

  return select( fd+1 , &fdset , NULL , NULL , &timeout );
}


void Drone_Keyboard_Control::showHelp()
{
  puts("\n");
  puts("---------------------------");
  puts("Operate from keyboard");
  puts("---------------------------");
  puts("Space: Stop");
  puts("---------------------------");
  puts("w: Go Forward");
  puts("s: Go Back");
  puts("d: Translate Right");
  puts("a: Translate Left");
  puts("(Arrow Equivalents Work as well)");
  puts("---------------------------");
  puts("u: Fly Up");
  puts("j: Fly Down");
  puts("l: Land");
  puts("---------------------------");
  puts("e: Rotate Clockwise");
  puts("q: Rotate AntiClockwise");
  puts("---------------------------");
  puts("p: Fly Scanning Pattern");
}


void Drone_Keyboard_Control::keyLoop(int argc, char** argv)
{
  char c;
  int  ret;
  char buf[1024];

  /////////////////////////////////////////////
  // get the console in raw mode
  int kfd = 0;
  struct termios cooked;

  struct termios raw;
  tcgetattr(kfd, &cooked);
  memcpy(&raw, &cooked, sizeof(struct termios));
  raw.c_lflag &=~ (ICANON | ECHO);
  raw.c_cc[VEOL] = 1;
  raw.c_cc[VEOF] = 2;
  tcsetattr(kfd, TCSANOW, &raw);
  /////////////////////////////////////////////

  ros::init(argc, argv, "gnc_node");

  ros::NodeHandle gnc_node("~");

  init_publisher_subscriber(gnc_node);

  wait4connect();
  wait4start();
  initialize_local_frame();
  takeoff(3);
  ros::Rate rate(2);
  showHelp();

  while (ros::ok())
  {
    if(canReceiveKey(kfd))
    {
      // get the next event from the keyboard
      if((ret = read(kfd, &buf, sizeof(buf))) < 0)
      {
        perror("read():");
        exit(EXIT_FAILURE);
      }

      c = buf[ret-1];

      switch(c)
      {
        case KEYCODE_SPACE:
        {
          ROS_DEBUG("Stop");
          set_mode("brake");
          break;
        }
        case KEY_W:
        case KEYCODE_UP:
        {
          ROS_DEBUG("Go Forward");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_destination(0,1000,0,0);
          
          
          break;
        }
        case KEY_S:
        case KEYCODE_DOWN:
        {
          ROS_DEBUG("Go Back");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_destination(0,-1000,0,0);
          break;
        }
        case KEY_D:
        case KEYCODE_RIGHT:
        {
          ROS_DEBUG("Turn Right");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_destination(1000,0,0,0);
          break;
        }
        case KEY_A:
        case KEYCODE_LEFT:
        {
          ROS_DEBUG("Turn Left");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_destination(-1000,0,0,0);
          break;
        }
        case KEY_E:
        {
          ROS_DEBUG("RotateRight");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_yaw(180,0.25,-1,1);
          break;
        }
        case KEY_Q:
        {
          ROS_DEBUG("RotateLeft");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_yaw(180,0.25,1,1);
          break;
        }
        case KEY_U:
        {
          ROS_DEBUG("Rotate Arm - Upward");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_destination(90,0,1000,0);
          break;
        }
        case KEY_J:
        {
          ROS_DEBUG("Rotate Arm - Horizontal");
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          set_destination(0,0,-1000,0);
          break;
        }

        case KEY_L:
        {
          ROS_DEBUG("Landing");
          land();
          break;
        }
        case KEY_P:
        {
          set_mode("brake");
          initialize_local_frame();
          set_mode("guided");
          std::vector<gnc_api_waypoint> waypointList;
          gnc_api_waypoint nextWayPoint;
          int m = 5;
          int n = 10;

          for( int i=0; i<m; i++){
            if(i%2==0)
            {
                for(int j=0; j<n; j++) {
                    nextWayPoint.x = (i*5);
                    nextWayPoint.y = (j*5);
                    nextWayPoint.z = 0;
                    nextWayPoint.psi = 0;
                    
                    waypointList.push_back(nextWayPoint);
                }
            }
            else{

                for(int j=n-1; j>=0; j--) {
                    nextWayPoint.x = (i*5);
                    nextWayPoint.y = (j*5);
                    nextWayPoint.z = 0;
                    nextWayPoint.psi = 0;
                    waypointList.push_back(nextWayPoint);
                }
            }
        }


      // for (int i = 0; i < waypointList.size(); i++) {
      //   cout << waypointList[i].x << " " << waypointList[i].y << "\n";
      // }

        int counter = 0;
        set_destination(0,0,0,0);
        


        bool flag = true;

        while (flag == true) {
          ros::spinOnce();
		      rate.sleep();
        if(check_waypoint_reached(4) == 1)
		{
			if (counter < waypointList.size())
			{
				set_destination(waypointList[counter].x,waypointList[counter].y,waypointList[counter].z, waypointList[counter].psi);
				cout << waypointList[counter].x << " " << waypointList[counter].y << " " << waypointList[counter].z << "\n";
        counter++;	
			}else{
				//land after all waypoints are reached
        flag = false;
				land();
			}	
		}	
        }
          
          break;
        }

        
      }
    }

    ros::spinOnce();

    rate.sleep();
  }

  /////////////////////////////////////////////
  // cooked mode
  tcsetattr(kfd, TCSANOW, &cooked);
  /////////////////////////////////////////////

  return;
}


int main(int argc, char** argv)
{
  Drone_Keyboard_Control init_process;

  init_process.keyLoop(argc, argv);

  return(EXIT_SUCCESS);
}

